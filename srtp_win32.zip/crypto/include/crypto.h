/*
 * crypto.h
 *
 * API for libcrypto
 * 
 * David A. McGrew
 * Cisco Systems, Inc.
 */

#ifndef CRYPTO_H
#define CRYPTO_H

#include "crypto_kernel.h"

#endif /* CRYPTO_H */


